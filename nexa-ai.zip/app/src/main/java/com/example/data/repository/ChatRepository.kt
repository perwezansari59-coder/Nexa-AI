package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import com.example.data.api.GeminiClient
import com.example.data.api.GeminiGenerationResult
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext

class ChatRepository(private val context: Context) {

    private val database = AppDatabase.getInstance(context)
    private val chatDao = database.chatDao()
    private val geminiClient = GeminiClient(context)

    val allConversations: Flow<List<ConversationEntity>> = chatDao.getAllConversations()
    val totalMessageCount: Flow<Int> = chatDao.getTotalMessageCount()

    fun getConversationsForUser(userEmail: String): Flow<List<ConversationEntity>> =
        if (userEmail.isBlank()) chatDao.getAllConversations()
        else chatDao.getConversationsForUser(userEmail)

    fun getConversation(id: Long): Flow<ConversationEntity?> = chatDao.getConversationById(id)

    fun getMessages(conversationId: Long): Flow<List<MessageEntity>> =
        chatDao.getMessagesForConversation(conversationId)

    suspend fun createNewConversation(title: String = "New Conversation", userEmail: String = ""): Long = withContext(Dispatchers.IO) {
        val conversation = ConversationEntity(
            title = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            userEmail = userEmail
        )
        chatDao.insertConversation(conversation)
    }

    suspend fun updateConversationTitle(id: Long, newTitle: String) = withContext(Dispatchers.IO) {
        val conv = chatDao.getConversationById(id).firstOrNull()
        if (conv != null) {
            chatDao.updateConversation(conv.copy(title = newTitle, updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun deleteConversation(id: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesByConversationId(id)
        chatDao.deleteConversationById(id)
    }

    suspend fun clearAllHistory() = withContext(Dispatchers.IO) {
        chatDao.deleteAllConversations()
    }

    suspend fun deleteMessage(messageId: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessageById(messageId)
    }

    suspend fun sendMessage(
        conversationId: Long,
        prompt: String,
        imageBitmap: Bitmap? = null,
        imageUriString: String? = null,
        documentName: String? = null,
        documentText: String? = null,
        enableWebGrounding: Boolean = false,
        languagePreference: String = "Auto"
    ): GeminiGenerationResult = withContext(Dispatchers.IO) {
        var activeConvId = conversationId

        // Ensure conversation exists or create one
        if (activeConvId <= 0) {
            val smartTitle = generateSmartTitle(prompt, documentName, imageBitmap != null)
            activeConvId = createNewConversation(smartTitle)
        }

        // 1. Insert User Message
        val userMessage = MessageEntity(
            conversationId = activeConvId,
            sender = "user",
            text = prompt,
            timestamp = System.currentTimeMillis(),
            imageUri = imageUriString,
            documentName = documentName
        )
        chatDao.insertMessage(userMessage)

        // 2. Fetch recent conversation messages for contextual chat
        val previousMessages = chatDao.getMessagesForConversation(activeConvId).firstOrNull() ?: emptyList()
        val historyTurns = previousMessages.dropLast(1).map { it.sender to it.text }

        // Update conversation title if it was "New Conversation"
        val currentConv = chatDao.getConversationById(activeConvId).firstOrNull()
        if (currentConv != null && (currentConv.title == "New Conversation" || currentConv.title.isBlank())) {
            val title = generateSmartTitle(prompt, documentName, imageBitmap != null)
            chatDao.updateConversation(currentConv.copy(title = title, updatedAt = System.currentTimeMillis()))
        } else if (currentConv != null) {
            chatDao.updateConversation(currentConv.copy(updatedAt = System.currentTimeMillis()))
        }

        // 3. Call Gemini API
        val result = geminiClient.generateResponse(
            prompt = prompt,
            history = historyTurns,
            imageBitmap = imageBitmap,
            documentText = documentText,
            enableWebGrounding = enableWebGrounding,
            languagePreference = languagePreference
        )

        // 4. Insert Assistant Message
        val assistantMessage = MessageEntity(
            conversationId = activeConvId,
            sender = "assistant",
            text = result.text,
            timestamp = System.currentTimeMillis(),
            isWebGrounded = result.isWebGrounded
        )
        chatDao.insertMessage(assistantMessage)

        result
    }

    suspend fun regenerateLastMessage(
        conversationId: Long,
        enableWebGrounding: Boolean,
        languagePreference: String
    ): GeminiGenerationResult? = withContext(Dispatchers.IO) {
        val messages = chatDao.getMessagesForConversation(conversationId).firstOrNull() ?: return@withContext null
        if (messages.isEmpty()) return@withContext null

        // Find last user message
        val lastUserMsg = messages.lastOrNull { it.sender == "user" } ?: return@withContext null

        // If the last message was assistant, remove it before regenerating
        if (messages.last().sender == "assistant") {
            chatDao.deleteMessageById(messages.last().id)
        }

        // History before that user message
        val historyTurns = messages
            .filter { it.id < lastUserMsg.id }
            .map { it.sender to it.text }

        val result = geminiClient.generateResponse(
            prompt = lastUserMsg.text,
            history = historyTurns,
            enableWebGrounding = enableWebGrounding,
            languagePreference = languagePreference
        )

        val assistantMessage = MessageEntity(
            conversationId = conversationId,
            sender = "assistant",
            text = result.text,
            timestamp = System.currentTimeMillis(),
            isWebGrounded = result.isWebGrounded
        )
        chatDao.insertMessage(assistantMessage)

        result
    }

    private fun generateSmartTitle(prompt: String, docName: String?, hasImage: Boolean): String {
        return when {
            prompt.isNotBlank() -> {
                val cleaned = prompt.lines().firstOrNull()?.trim() ?: "Conversation"
                if (cleaned.length > 32) cleaned.substring(0, 32) + "..." else cleaned
            }
            !docName.isNullOrBlank() -> "Doc: $docName"
            hasImage -> "Image Analysis"
            else -> "Chat ${System.currentTimeMillis() % 10000}"
        }
    }
}
