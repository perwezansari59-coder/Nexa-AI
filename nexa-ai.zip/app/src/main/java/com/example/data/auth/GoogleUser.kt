package com.example.data.auth

data class GoogleUser(
    val id: String,
    val email: String,
    val displayName: String,
    val photoUrl: String? = null,
    val idToken: String? = null,
    val lastSignIn: Long = System.currentTimeMillis()
)
