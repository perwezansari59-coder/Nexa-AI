package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val isDarkMode: Boolean = false,
    val isEdgeGlowEnabled: Boolean = true,
    val edgeGlowIntensity: Float = 0.45f,
    val languagePreference: String = "Auto", // Auto, English, Hindi, Hinglish
    val isWebGroundingEnabled: Boolean = false,
    val isTtsAutoPlay: Boolean = false,
    val ttsSpeechRate: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val userName: String = "Nexa Explorer",
    val userEmail: String = "user@nexa.ai",
    val userPhotoUrl: String = "",
    val userPlan: String = "Free" // Free, Pro
)

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexa_ai_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        return AppSettings(
            isDarkMode = prefs.getBoolean("is_dark_mode", false),
            isEdgeGlowEnabled = prefs.getBoolean("is_edge_glow_enabled", true),
            edgeGlowIntensity = prefs.getFloat("edge_glow_intensity", 0.45f),
            languagePreference = prefs.getString("language_pref", "Auto") ?: "Auto",
            isWebGroundingEnabled = prefs.getBoolean("web_grounding", false),
            isTtsAutoPlay = prefs.getBoolean("tts_autoplay", false),
            ttsSpeechRate = prefs.getFloat("tts_rate", 1.0f),
            ttsPitch = prefs.getFloat("tts_pitch", 1.0f),
            userName = prefs.getString("user_name", "Nexa Explorer") ?: "Nexa Explorer",
            userEmail = prefs.getString("user_email", "explorer@nexa.ai") ?: "explorer@nexa.ai",
            userPhotoUrl = prefs.getString("user_photo_url", "") ?: "",
            userPlan = prefs.getString("user_plan", "Free") ?: "Free"
        )
    }

    fun updateDarkMode(isDark: Boolean) {
        prefs.edit().putBoolean("is_dark_mode", isDark).apply()
        _settings.value = _settings.value.copy(isDarkMode = isDark)
    }

    fun updateEdgeGlow(enabled: Boolean) {
        prefs.edit().putBoolean("is_edge_glow_enabled", enabled).apply()
        _settings.value = _settings.value.copy(isEdgeGlowEnabled = enabled)
    }

    fun updateEdgeGlowIntensity(intensity: Float) {
        prefs.edit().putFloat("edge_glow_intensity", intensity).apply()
        _settings.value = _settings.value.copy(edgeGlowIntensity = intensity)
    }

    fun updateLanguage(lang: String) {
        prefs.edit().putString("language_pref", lang).apply()
        _settings.value = _settings.value.copy(languagePreference = lang)
    }

    fun updateWebGrounding(enabled: Boolean) {
        prefs.edit().putBoolean("web_grounding", enabled).apply()
        _settings.value = _settings.value.copy(isWebGroundingEnabled = enabled)
    }

    fun updateTtsAutoPlay(enabled: Boolean) {
        prefs.edit().putBoolean("tts_autoplay", enabled).apply()
        _settings.value = _settings.value.copy(isTtsAutoPlay = enabled)
    }

    fun updateTtsSettings(rate: Float, pitch: Float) {
        prefs.edit()
            .putFloat("tts_rate", rate)
            .putFloat("tts_pitch", pitch)
            .apply()
        _settings.value = _settings.value.copy(ttsSpeechRate = rate, ttsPitch = pitch)
    }

    fun updateProfile(name: String, email: String, photoUrl: String = "") {
        prefs.edit()
            .putString("user_name", name)
            .putString("user_email", email)
            .putString("user_photo_url", photoUrl)
            .apply()
        _settings.value = _settings.value.copy(userName = name, userEmail = email, userPhotoUrl = photoUrl)
    }

    fun updateUserPlan(plan: String) {
        prefs.edit()
            .putString("user_plan", plan)
            .apply()
        _settings.value = _settings.value.copy(userPlan = plan)
    }
}
