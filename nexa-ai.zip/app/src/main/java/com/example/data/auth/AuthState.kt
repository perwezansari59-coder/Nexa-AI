package com.example.data.auth

sealed interface AuthState {
    object Initializing : AuthState
    object Unauthenticated : AuthState
    data class Loading(val message: String = "Connecting to Google...") : AuthState
    data class Authenticated(val user: GoogleUser) : AuthState
    data class Error(val message: String) : AuthState
}
