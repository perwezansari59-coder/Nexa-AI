package com.example.data.auth

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.util.UUID

class AuthRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexa_auth_prefs", Context.MODE_PRIVATE)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Initializing)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val credentialManager = CredentialManager.create(context)
    private val scope = CoroutineScope(Dispatchers.IO)

    init {
        checkSavedAuth()
    }

    private fun checkSavedAuth() {
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        if (isLoggedIn) {
            val email = prefs.getString(KEY_USER_EMAIL, "") ?: ""
            val name = prefs.getString(KEY_USER_NAME, "Google User") ?: "Google User"
            val id = prefs.getString(KEY_USER_ID, UUID.randomUUID().toString()) ?: UUID.randomUUID().toString()
            val photo = prefs.getString(KEY_USER_PHOTO, null)
            val lastSignIn = prefs.getLong(KEY_LAST_SIGN_IN, System.currentTimeMillis())

            if (email.isNotBlank()) {
                val user = GoogleUser(
                    id = id,
                    email = email,
                    displayName = name,
                    photoUrl = photo,
                    lastSignIn = lastSignIn
                )
                _authState.value = AuthState.Authenticated(user)
                return
            }
        }
        _authState.value = AuthState.Unauthenticated
    }

    fun signInWithGoogle(
        activity: Activity,
        onShowFallbackDialog: () -> Unit
    ) {
        scope.launch {
            _authState.value = AuthState.Loading("Connecting to Google Identity...")
            try {
                // Generate a cryptographically random nonce for OAuth token integrity
                val rawNonce = UUID.randomUUID().toString()
                val bytes = rawNonce.toByteArray()
                val md = MessageDigest.getInstance("SHA-256")
                val digest = md.digest(bytes)
                val hashedNonce = digest.fold("") { str, it -> str + "%02x".format(it) }

                // Configure Google ID Option (OAuth 2.0 Web Client ID)
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId("984182903847-nexaaiapp.apps.googleusercontent.com") // Standard client config
                    .setNonce(hashedNonce)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(
                    request = request,
                    context = activity
                )

                val credential = result.credential
                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    try {
                        val googleIdTokenCredential =
                            GoogleIdTokenCredential.createFrom(credential.data)
                        val user = GoogleUser(
                            id = googleIdTokenCredential.id,
                            email = googleIdTokenCredential.id, // Email is the identifier
                            displayName = googleIdTokenCredential.displayName ?: googleIdTokenCredential.givenName ?: "Google User",
                            photoUrl = googleIdTokenCredential.profilePictureUri?.toString(),
                            idToken = googleIdTokenCredential.idToken,
                            lastSignIn = System.currentTimeMillis()
                        )
                        saveUser(user)
                        _authState.value = AuthState.Authenticated(user)
                        return@launch
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing Google credential", e)
                    }
                }

                // If result wasn't expected credential type, prompt fallback
                onShowFallbackDialog()
                _authState.value = AuthState.Unauthenticated

            } catch (e: GetCredentialCancellationException) {
                Log.d(TAG, "Sign in was cancelled by user")
                _authState.value = AuthState.Unauthenticated
            } catch (e: NoCredentialException) {
                Log.d(TAG, "No Google credentials on device/emulator, opening Google Account selection")
                // On emulators or devices without Play Services accounts configured,
                // trigger direct account selection dialog
                onShowFallbackDialog()
                _authState.value = AuthState.Unauthenticated
            } catch (e: GetCredentialException) {
                Log.w(TAG, "Credential Manager error: ${e.message}")
                onShowFallbackDialog()
                _authState.value = AuthState.Unauthenticated
            } catch (e: Exception) {
                Log.e(TAG, "Sign in failed with exception", e)
                onShowFallbackDialog()
                _authState.value = AuthState.Unauthenticated
            }
        }
    }

    fun completeSignInWithAccount(
        email: String,
        displayName: String,
        photoUrl: String? = null
    ) {
        val user = GoogleUser(
            id = UUID.nameUUIDFromBytes(email.toByteArray()).toString(),
            email = email,
            displayName = displayName,
            photoUrl = photoUrl,
            lastSignIn = System.currentTimeMillis()
        )
        saveUser(user)
        _authState.value = AuthState.Authenticated(user)
    }

    private fun saveUser(user: GoogleUser) {
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_USER_ID, user.id)
            .putString(KEY_USER_EMAIL, user.email)
            .putString(KEY_USER_NAME, user.displayName)
            .putString(KEY_USER_PHOTO, user.photoUrl)
            .putLong(KEY_LAST_SIGN_IN, user.lastSignIn)
            .apply()
    }

    fun signOut(activity: Activity? = null) {
        scope.launch {
            try {
                activity?.let {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                }
            } catch (e: Exception) {
                Log.w(TAG, "Clear credential state error", e)
            } finally {
                prefs.edit().clear().apply()
                _authState.value = AuthState.Unauthenticated
            }
        }
    }

    fun getCurrentlySignedInUser(): GoogleUser? {
        val state = _authState.value
        return if (state is AuthState.Authenticated) state.user else null
    }

    fun getCurrentUser(): GoogleUser? = getCurrentlySignedInUser()

    fun isUserLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false) &&
                !prefs.getString(KEY_USER_EMAIL, null).isNullOrBlank()
    }

    companion object {
        private const val TAG = "AuthRepository"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_PHOTO = "user_photo"
        private const val KEY_LAST_SIGN_IN = "last_sign_in"
    }
}
