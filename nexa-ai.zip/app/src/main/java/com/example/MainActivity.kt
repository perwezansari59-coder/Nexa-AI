package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.auth.AuthState
import com.example.ui.auth.LoginScreen
import com.example.ui.chat.ChatScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.components.AnimatedEdgeGlowContainer
import com.example.ui.components.NexaBottomNavigationBar
import com.example.ui.components.NexaTopBar
import com.example.ui.history.HistoryScreen
import com.example.ui.home.HomeScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.upgrade.UpgradeScreen
import com.example.ui.theme.NexaTheme

class MainActivity : ComponentActivity() {

    private val chatViewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by chatViewModel.settings.collectAsState()
            val conversations by chatViewModel.conversations.collectAsState()
            val authState by chatViewModel.authState.collectAsState()

            NexaTheme(darkTheme = settings.isDarkMode) {
                // Outer Ambient Edge Glow Container
                AnimatedEdgeGlowContainer(
                    enabled = settings.isEdgeGlowEnabled,
                    intensity = settings.edgeGlowIntensity
                ) {
                    val navController = rememberNavController()
                    val startDest = remember { if (chatViewModel.isUserLoggedIn()) "home" else "login" }

                    NavHost(
                        navController = navController,
                        startDestination = startDest,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Google Authentication Welcome / Login Screen
                        composable("login") {
                            LoginScreen(
                                authState = authState,
                                onSignInWithGoogle = { activity, onFallback ->
                                    chatViewModel.signInWithGoogle(activity, onFallback)
                                },
                                onCompleteSignInWithAccount = { email, name, photo ->
                                    chatViewModel.completeSignInWithAccount(email, name, photo)
                                },
                                onSignInSuccess = {
                                    navController.navigate("home") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                }
                            )
                        }

                        // Home Screen
                        composable("home") {
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                topBar = {
                                    NexaTopBar(
                                        title = "Nexa AI",
                                        subtitle = "Next-Gen Intelligence",
                                        showBackButton = false,
                                        showNewChatButton = true,
                                        onNewChatClick = {
                                            chatViewModel.startNewChat()
                                            navController.navigate("chat")
                                        },
                                        showHistoryButton = true,
                                        onHistoryClick = {
                                            navController.navigate("history")
                                        },
                                        showSettingsButton = true,
                                        onSettingsClick = {
                                            navController.navigate("settings")
                                        },
                                        isDarkMode = settings.isDarkMode,
                                        onToggleTheme = {
                                            chatViewModel.updateDarkMode(!settings.isDarkMode)
                                        }
                                    )
                                },
                                bottomBar = {
                                    NexaBottomNavigationBar(
                                        currentRoute = "home",
                                        onNavigateToRoute = { route ->
                                            navController.navigate(route) {
                                                popUpTo("home") { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )
                                }
                            ) { innerPadding ->
                                HomeScreen(
                                    conversations = conversations,
                                    userDisplayName = settings.userName,
                                    userEmail = settings.userEmail,
                                    userPhotoUrl = settings.userPhotoUrl,
                                    userPlan = settings.userPlan,
                                    onNewChat = {
                                        chatViewModel.startNewChat()
                                        navController.navigate("chat")
                                    },
                                    onOpenChat = { id ->
                                        chatViewModel.openConversation(id)
                                        navController.navigate("chat")
                                    },
                                    onOpenHistory = {
                                        navController.navigate("history")
                                    },
                                    onOpenUpgrade = {
                                        navController.navigate("upgrade")
                                    },
                                    onDeleteChat = { id ->
                                        chatViewModel.deleteConversation(id)
                                    },
                                    onImageSelected = { bitmap, uri ->
                                        chatViewModel.startNewChat()
                                        chatViewModel.attachImage(bitmap, uri)
                                        navController.navigate("chat")
                                    },
                                    onDocumentSelected = { name, text ->
                                        chatViewModel.startNewChat()
                                        chatViewModel.attachDocument(name, text)
                                        navController.navigate("chat")
                                    },
                                    onVoicePrompt = { prompt ->
                                        chatViewModel.startNewChat()
                                        navController.navigate("chat")
                                        chatViewModel.sendMessage(prompt)
                                    },
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }

                        // Chat Screen
                        composable("chat") {
                            Scaffold(
                                modifier = Modifier.fillMaxSize()
                            ) { innerPadding ->
                                ChatScreen(
                                    viewModel = chatViewModel,
                                    onBack = {
                                        navController.popBackStack()
                                    },
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }

                        // History Screen
                        composable("history") {
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                bottomBar = {
                                    NexaBottomNavigationBar(
                                        currentRoute = "history",
                                        onNavigateToRoute = { route ->
                                            navController.navigate(route) {
                                                popUpTo("home") { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )
                                }
                            ) { innerPadding ->
                                HistoryScreen(
                                    conversations = conversations,
                                    onOpenConversation = { id ->
                                        chatViewModel.openConversation(id)
                                        navController.navigate("chat")
                                    },
                                    onDeleteConversation = { id ->
                                        chatViewModel.deleteConversation(id)
                                    },
                                    onRenameConversation = { id, title ->
                                        chatViewModel.renameConversation(id, title)
                                    },
                                    onClearAll = {
                                        chatViewModel.clearAllHistory()
                                    },
                                    onNewChat = {
                                        chatViewModel.startNewChat()
                                        navController.navigate("chat")
                                    },
                                    onBack = {
                                        navController.popBackStack()
                                    },
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }

                        // Upgrade Screen (Nexa AI Pro subscription)
                        composable("upgrade") {
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                bottomBar = {
                                    NexaBottomNavigationBar(
                                        currentRoute = "upgrade",
                                        onNavigateToRoute = { route ->
                                            navController.navigate(route) {
                                                popUpTo("home") { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )
                                }
                            ) { innerPadding ->
                                UpgradeScreen(
                                    viewModel = chatViewModel,
                                    onBack = {
                                        if (navController.previousBackStackEntry != null) {
                                            navController.popBackStack()
                                        } else {
                                            navController.navigate("home")
                                        }
                                    },
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }

                        // Settings Screen
                        composable("settings") {
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                bottomBar = {
                                    NexaBottomNavigationBar(
                                        currentRoute = "settings",
                                        onNavigateToRoute = { route ->
                                            navController.navigate(route) {
                                                popUpTo("home") { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )
                                }
                            ) { innerPadding ->
                                SettingsScreen(
                                    viewModel = chatViewModel,
                                    onBack = {
                                        if (navController.previousBackStackEntry != null) {
                                            navController.popBackStack()
                                        } else {
                                            navController.navigate("home")
                                        }
                                    },
                                    onSignOut = {
                                        navController.navigate("login") {
                                            popUpTo(0) { inclusive = true }
                                        }
                                    },
                                    onOpenUpgrade = {
                                        navController.navigate("upgrade")
                                    },
                                    modifier = Modifier.padding(innerPadding)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
