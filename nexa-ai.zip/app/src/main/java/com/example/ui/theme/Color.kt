package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Nexa AI Color Palette
val NexaDarkBackground = Color(0xFF090A11)
val NexaDarkSurface = Color(0xFF111322)
val NexaDarkSurfaceVariant = Color(0xFF1A1C30)
val NexaDarkSurfaceElevated = Color(0xFF21253E)
val NexaDarkBorder = Color(0xFF2E3354)

// Neon Accent Colors (Blue, Purple, Pink, Cyan, Green)
val NexaBlue = Color(0xFF2979FF)
val NexaPurple = Color(0xFF9D4EDD)
val NexaPink = Color(0xFFFF2A85)
val NexaCyan = Color(0xFF00E5FF)
val NexaGreen = Color(0xFF00E676)

val NexaGlowColors = listOf(
    NexaBlue,
    NexaPurple,
    NexaPink,
    NexaCyan,
    NexaGreen
)

// Light Theme Palette (Clean White & Slate)
val NexaLightBackground = Color(0xFFFFFFFF)
val NexaLightSurface = Color(0xFFFFFFFF)
val NexaLightSurfaceVariant = Color(0xFFF1F5F9)
val NexaLightSurfaceElevated = Color(0xFFF8FAFC)
val NexaLightBorder = Color(0xFFE2E8F0)

// Text Colors
val NexaLightTextPrimary = Color(0xFF0F172A)
val NexaLightTextSecondary = Color(0xFF475569)
val NexaLightTextTertiary = Color(0xFF64748B)

// Chat Bubbles
val NexaUserBubbleDark = Color(0xFF1E2442)
val NexaAiBubbleDark = Color(0xFF131627)
val NexaUserBubbleLight = Color(0xFF0F172A) // Modern crisp dark slate bubble with white text
val NexaAiBubbleLight = Color(0xFFF8FAFC)   // Clean light card with subtle border and dark readable text
