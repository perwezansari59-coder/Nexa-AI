package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.example.ui.theme.NexaBlue
import com.example.ui.theme.NexaCyan
import com.example.ui.theme.NexaGreen
import com.example.ui.theme.NexaPink
import com.example.ui.theme.NexaPurple

@Composable
fun AnimatedEdgeGlowContainer(
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    intensity: Float = 0.45f,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.fillMaxSize()) {
        content()

        if (enabled && intensity > 0f) {
            val infiniteTransition = rememberInfiniteTransition(label = "edgeGlowTransition")
            val animatedOffset by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 7000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "edgeGlowOffset"
            )

            Canvas(
                modifier = Modifier.fillMaxSize()
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val glowWidth = (canvasWidth * 0.055f).coerceIn(18f, 42f)

                val leftColor1 = sampleGlowColor(animatedOffset, 0.0f)
                val leftColor2 = sampleGlowColor(animatedOffset, 0.25f)
                val rightColor1 = sampleGlowColor(animatedOffset, 0.5f)
                val rightColor2 = sampleGlowColor(animatedOffset, 0.75f)

                // Left Edge Glow (Soft multicolor transition)
                val leftBrush = Brush.horizontalGradient(
                    colors = listOf(
                        leftColor1.copy(alpha = intensity * 0.5f),
                        leftColor2.copy(alpha = intensity * 0.22f),
                        Color.Transparent
                    ),
                    startX = 0f,
                    endX = glowWidth
                )

                drawRect(
                    brush = leftBrush,
                    topLeft = Offset(0f, 0f),
                    size = Size(glowWidth, canvasHeight)
                )

                // Right Edge Glow (Soft multicolor transition)
                val rightBrush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        rightColor1.copy(alpha = intensity * 0.22f),
                        rightColor2.copy(alpha = intensity * 0.5f)
                    ),
                    startX = canvasWidth - glowWidth,
                    endX = canvasWidth
                )

                drawRect(
                    brush = rightBrush,
                    topLeft = Offset(canvasWidth - glowWidth, 0f),
                    size = Size(glowWidth, canvasHeight)
                )
            }
        }
    }
}

private fun sampleGlowColor(progress: Float, shift: Float): Color {
    val colors = listOf(
        NexaBlue,
        NexaPurple,
        NexaPink,
        NexaCyan,
        NexaGreen,
        NexaBlue
    )
    val totalSteps = colors.size - 1
    val normalized = ((progress + shift) % 1f + 1f) % 1f
    val rawIndex = normalized * totalSteps
    val index = rawIndex.toInt().coerceIn(0, totalSteps - 1)
    val fraction = rawIndex - index
    return lerp(colors[index], colors[index + 1], fraction)
}
