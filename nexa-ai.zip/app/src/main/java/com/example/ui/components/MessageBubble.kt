package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.MessageEntity
import com.example.ui.theme.NexaBlue
import com.example.ui.theme.NexaCyan
import com.example.ui.theme.NexaGreen
import com.example.ui.theme.NexaPink
import com.example.ui.theme.NexaPurple
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MessageBubble(
    message: MessageEntity,
    isLastAiMessage: Boolean = false,
    isPlayingTts: Boolean = false,
    onPlayTts: (String) -> Unit = {},
    onStopTts: () -> Unit = {},
    onRegenerate: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isUser = message.sender.equals("user", ignoreCase = true)
    var copiedState by remember { mutableStateOf(false) }

    val bubbleShape = if (isUser) {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp)
    } else {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 4.dp, bottomEnd = 18.dp)
    }

    val bubbleBackground = if (isUser) {
        Brush.linearGradient(
            listOf(
                Color(0xFF0F172A),
                Color(0xFF1E293B)
            )
        )
    } else {
        Brush.linearGradient(
            listOf(
                MaterialTheme.colorScheme.surface,
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
        )
    }

    val borderStroke = if (isUser) {
        BorderStrokeModifier(1.dp, NexaBlue.copy(alpha = 0.35f))
    } else {
        BorderStrokeModifier(1.dp, NexaPurple.copy(alpha = 0.35f))
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.Top
        ) {
            // Avatar for AI
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(NexaCyan, NexaPurple, NexaPink))
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Nexa AI",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            Column(
                modifier = Modifier.widthIn(max = 320.dp),
                horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
            ) {
                // Attached Image Preview
                if (!message.imageUri.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, NexaCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    ) {
                        AsyncImage(
                            model = Uri.parse(message.imageUri),
                            contentDescription = "Attached image",
                            modifier = Modifier
                                .size(width = 180.dp, height = 130.dp),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                // Attached Document Badge
                if (!message.documentName.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = NexaCyan.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NexaCyan.copy(alpha = 0.4f)),
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = "Document",
                                tint = NexaCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = message.documentName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NexaCyan
                            )
                        }
                    }
                }

                // Main Bubble
                Box(
                    modifier = Modifier
                        .clip(bubbleShape)
                        .background(bubbleBackground)
                        .border(
                            width = 1.dp,
                            brush = if (isUser) {
                                Brush.linearGradient(listOf(NexaBlue.copy(alpha = 0.4f), NexaCyan.copy(alpha = 0.2f)))
                            } else {
                                Brush.linearGradient(listOf(NexaPurple.copy(alpha = 0.4f), NexaPink.copy(alpha = 0.2f)))
                            },
                            shape = bubbleShape
                        )
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Column {
                        // Web Grounded Badge
                        if (message.isWebGrounded) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .padding(bottom = 6.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(NexaGreen.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "🌐 Live Web Grounded",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NexaGreen
                                )
                            }
                        }

                        // Message Text with smart code formatting
                        FormattedMessageContent(text = message.text, isUser = isUser)

                        // Timestamp
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            val timeStr = remember(message.timestamp) {
                                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp))
                            }
                            Text(
                                text = timeStr,
                                fontSize = 10.sp,
                                color = if (isUser) Color.White.copy(alpha = 0.75f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                // AI Action Row (Copy, TTS, Share, Regenerate)
                if (!isUser) {
                    Row(
                        modifier = Modifier
                            .padding(top = 4.dp, start = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Copy Button
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Nexa AI Answer", message.text)
                                clipboard.setPrimaryClip(clip)
                                copiedState = true
                                Toast.makeText(context, "Answer copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("copy_answer_button")
                        ) {
                            Icon(
                                imageVector = if (copiedState) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "Copy Answer",
                                tint = if (copiedState) NexaGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                        }

                        // TTS Button
                        IconButton(
                            onClick = {
                                if (isPlayingTts) {
                                    onStopTts()
                                } else {
                                    onPlayTts(message.text)
                                }
                            },
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("tts_answer_button")
                        ) {
                            Icon(
                                imageVector = if (isPlayingTts) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = if (isPlayingTts) "Stop Audio" else "Listen",
                                tint = if (isPlayingTts) NexaPink else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Share Button
                        IconButton(
                            onClick = {
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "${message.text}\n\n— Generated by Nexa AI")
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, "Share Nexa AI Answer")
                                context.startActivity(shareIntent)
                            },
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("share_answer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share Answer",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                        }

                        // Regenerate Button (available on last AI message)
                        if (isLastAiMessage) {
                            IconButton(
                                onClick = onRegenerate,
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("regenerate_answer_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Regenerate Answer",
                                    tint = NexaCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Avatar for User
            if (isUser) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FormattedMessageContent(text: String, isUser: Boolean) {
    val context = LocalContext.current
    val segments = remember(text) { parseMessageSegments(text) }

    Column {
        for (segment in segments) {
            when (segment) {
                is TextSegment.CodeBlock -> {
                    // Code Card Block
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0D0E17))
                            .border(1.dp, Color(0xFF2E324A), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = segment.language.ifBlank { "Code" },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NexaCyan
                                )
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy code",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clickable {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Code", segment.code)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
                                        }
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = segment.code,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = Color(0xFFE2E8F0),
                                lineHeight = 17.sp
                            )
                        }
                    }
                }
                is TextSegment.NormalText -> {
                    Text(
                        text = segment.content,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }
        }
    }
}

private sealed class TextSegment {
    data class NormalText(val content: String) : TextSegment()
    data class CodeBlock(val language: String, val code: String) : TextSegment()
}

private fun parseMessageSegments(input: String): List<TextSegment> {
    val list = mutableListOf<TextSegment>()
    val codePattern = Regex("```([a-zA-Z0-9_-]*)\\n?([\\s\\S]*?)```")
    var lastIdx = 0

    val matches = codePattern.findAll(input)
    for (match in matches) {
        if (match.range.first > lastIdx) {
            val normal = input.substring(lastIdx, match.range.first)
            if (normal.isNotBlank()) {
                list.add(TextSegment.NormalText(normal.trim()))
            }
        }
        val lang = match.groupValues[1].trim()
        val code = match.groupValues[2].trim()
        list.add(TextSegment.CodeBlock(lang, code))
        lastIdx = match.range.last + 1
    }

    if (lastIdx < input.length) {
        val remaining = input.substring(lastIdx)
        if (remaining.isNotBlank()) {
            list.add(TextSegment.NormalText(remaining.trim()))
        }
    }

    if (list.isEmpty()) {
        list.add(TextSegment.NormalText(input))
    }

    return list
}

private fun BorderStrokeModifier(width: androidx.compose.ui.unit.Dp, color: Color) =
    androidx.compose.foundation.BorderStroke(width, color)
