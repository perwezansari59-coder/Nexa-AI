package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Pixel-perfect Google 'G' icon rendered with official brand colors:
 * - Blue: #4285F4
 * - Red: #EA4335
 * - Yellow: #FBBC05
 * - Green: #34A853
 */
@Composable
fun GoogleLogo(
    modifier: Modifier = Modifier,
    size: Dp = 20.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f
        val radius = (w.coerceAtMost(h)) / 2f

        val blue = Color(0xFF4285F4)
        val red = Color(0xFFEA4335)
        val yellow = Color(0xFFFBBC05)
        val green = Color(0xFF34A853)

        // Draw the 4 colored arcs forming the Google "G"
        // Red arc (top left to top right)
        val redPath = Path().apply {
            moveTo(cx, cy)
            arcTo(
                rect = Rect(Offset(cx - radius, cy - radius), Offset(cx + radius, cy + radius)),
                startAngleDegrees = -45f,
                sweepAngleDegrees = -90f,
                forceMoveTo = false
            )
            close()
        }
        drawPath(redPath, red, style = Fill)

        // Yellow arc (top left to bottom left)
        val yellowPath = Path().apply {
            moveTo(cx, cy)
            arcTo(
                rect = Rect(Offset(cx - radius, cy - radius), Offset(cx + radius, cy + radius)),
                startAngleDegrees = -135f,
                sweepAngleDegrees = -90f,
                forceMoveTo = false
            )
            close()
        }
        drawPath(yellowPath, yellow, style = Fill)

        // Green arc (bottom left to bottom right)
        val greenPath = Path().apply {
            moveTo(cx, cy)
            arcTo(
                rect = Rect(Offset(cx - radius, cy - radius), Offset(cx + radius, cy + radius)),
                startAngleDegrees = 135f,
                sweepAngleDegrees = -90f,
                forceMoveTo = false
            )
            close()
        }
        drawPath(greenPath, green, style = Fill)

        // Blue arc and horizontal bar (right quadrant)
        val bluePath = Path().apply {
            moveTo(cx, cy)
            arcTo(
                rect = Rect(Offset(cx - radius, cy - radius), Offset(cx + radius, cy + radius)),
                startAngleDegrees = 45f,
                sweepAngleDegrees = -90f,
                forceMoveTo = false
            )
            close()
        }
        drawPath(bluePath, blue, style = Fill)

        // Center circle cutout (White)
        val innerRadius = radius * 0.58f
        drawCircle(
            color = Color.White,
            radius = innerRadius,
            center = Offset(cx, cy)
        )

        // Blue horizontal bar in Google "G"
        val barHeight = radius * 0.38f
        val barWidth = radius * 0.88f
        drawRect(
            color = blue,
            topLeft = Offset(cx - radius * 0.05f, cy - barHeight / 2f),
            size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
        )
    }
}
