package com.example.ui.chat

import android.app.Activity
import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiGenerationResult
import com.example.data.auth.AuthRepository
import com.example.data.auth.AuthState
import com.example.data.auth.GoogleUser
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import com.example.data.repository.ChatRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale
import kotlinx.coroutines.ExperimentalCoroutinesApi

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(application: Application) : AndroidViewModel(application) {

    val authRepository = AuthRepository(application)
    private val chatRepository = ChatRepository(application)
    private val settingsRepository = SettingsRepository(application)

    val authState: StateFlow<AuthState> = authRepository.authState
    val settings = settingsRepository.settings

    val conversations: StateFlow<List<ConversationEntity>> = authState
        .flatMapLatest { state ->
            val email = (state as? AuthState.Authenticated)?.user?.email ?: ""
            chatRepository.getConversationsForUser(email)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalMessages: StateFlow<Int> = chatRepository.totalMessageCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _currentConversationId = MutableStateFlow<Long>(-1L)
    val currentConversationId: StateFlow<Long> = _currentConversationId.asStateFlow()

    val currentMessages: StateFlow<List<MessageEntity>> = _currentConversationId
        .flatMapLatest { id ->
            if (id > 0) chatRepository.getMessages(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentConversation: StateFlow<ConversationEntity?> = _currentConversationId
        .flatMapLatest { id ->
            if (id > 0) chatRepository.getConversation(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    // Attached Media
    private val _selectedImageBitmap = MutableStateFlow<Bitmap?>(null)
    val selectedImageBitmap: StateFlow<Bitmap?> = _selectedImageBitmap.asStateFlow()

    private val _selectedImageUri = MutableStateFlow<Uri?>(null)
    val selectedImageUri: StateFlow<Uri?> = _selectedImageUri.asStateFlow()

    private val _selectedDocName = MutableStateFlow<String?>(null)
    val selectedDocName: StateFlow<String?> = _selectedDocName.asStateFlow()

    private val _selectedDocText = MutableStateFlow<String?>(null)
    val selectedDocText: StateFlow<String?> = _selectedDocText.asStateFlow()

    // Web Search Grounding Toggle
    private val _isWebGroundingActive = MutableStateFlow(false)
    val isWebGroundingActive: StateFlow<Boolean> = _isWebGroundingActive.asStateFlow()

    // Text to Speech
    private var tts: TextToSpeech? = null
    private val _isPlayingTts = MutableStateFlow(false)
    val isPlayingTts: StateFlow<Boolean> = _isPlayingTts.asStateFlow()
    private val _currentSpeakingText = MutableStateFlow<String?>(null)

    init {
        initTts()
        viewModelScope.launch {
            authRepository.authState.collect { state ->
                if (state is AuthState.Authenticated) {
                    settingsRepository.updateProfile(
                        name = state.user.displayName,
                        email = state.user.email,
                        photoUrl = state.user.photoUrl ?: ""
                    )
                }
            }
        }
    }

    private fun initTts() {
        tts = TextToSpeech(getApplication()) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isPlayingTts.value = true
                    }
                    override fun onDone(utteranceId: String?) {
                        _isPlayingTts.value = false
                        _currentSpeakingText.value = null
                    }
                    override fun onError(utteranceId: String?) {
                        _isPlayingTts.value = false
                        _currentSpeakingText.value = null
                    }
                })
            }
        }
    }

    fun startNewChat() {
        _currentConversationId.value = -1L
        _lastError.value = null
        clearAttachedMedia()
    }

    fun openConversation(id: Long) {
        _currentConversationId.value = id
        _lastError.value = null
        clearAttachedMedia()
    }

    fun toggleWebGrounding() {
        _isWebGroundingActive.value = !_isWebGroundingActive.value
    }

    fun attachImage(bitmap: Bitmap, uri: Uri) {
        _selectedImageBitmap.value = bitmap
        _selectedImageUri.value = uri
    }

    fun clearAttachedImage() {
        _selectedImageBitmap.value = null
        _selectedImageUri.value = null
    }

    fun attachDocument(name: String, text: String) {
        _selectedDocName.value = name
        _selectedDocText.value = text
    }

    fun clearAttachedDocument() {
        _selectedDocName.value = null
        _selectedDocText.value = null
    }

    fun clearAttachedMedia() {
        clearAttachedImage()
        clearAttachedDocument()
    }

    fun sendMessage(prompt: String) {
        val trimmedPrompt = prompt.trim()
        val imageBitmap = _selectedImageBitmap.value
        val imageUriString = _selectedImageUri.value?.toString()
        val docName = _selectedDocName.value
        val docText = _selectedDocText.value

        if (trimmedPrompt.isEmpty() && imageBitmap == null && docText == null) {
            return
        }

        val grounding = _isWebGroundingActive.value
        val lang = settings.value.languagePreference

        // Clear input media immediately to avoid duplicate uploads
        clearAttachedMedia()
        _isLoading.value = true
        _lastError.value = null

        viewModelScope.launch {
            try {
                var convId = _currentConversationId.value
                if (convId <= 0) {
                    val initialTitle = when {
                        trimmedPrompt.isNotBlank() -> trimmedPrompt.take(30)
                        docName != null -> "Doc: $docName"
                        imageBitmap != null -> "Image Analysis"
                        else -> "New Chat"
                    }
                    val currentUserEmail = (authState.value as? AuthState.Authenticated)?.user?.email ?: ""
                    convId = chatRepository.createNewConversation(initialTitle, userEmail = currentUserEmail)
                    _currentConversationId.value = convId
                }

                val result: GeminiGenerationResult = chatRepository.sendMessage(
                    conversationId = convId,
                    prompt = trimmedPrompt.ifEmpty { "Analyze the attached file." },
                    imageBitmap = imageBitmap,
                    imageUriString = imageUriString,
                    documentName = docName,
                    documentText = docText,
                    enableWebGrounding = grounding,
                    languagePreference = lang
                )

                if (result.error != null && result.text.startsWith("Nexa AI encountered")) {
                    _lastError.value = result.error
                }

                // Autoplay TTS if enabled in settings
                if (settings.value.isTtsAutoPlay && result.text.isNotBlank()) {
                    speakText(result.text)
                }
            } catch (e: Exception) {
                Log.e("ChatViewModel", "Error sending message", e)
                _lastError.value = e.localizedMessage ?: "Unknown error sending message"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun regenerate() {
        val convId = _currentConversationId.value
        if (convId <= 0) return

        _isLoading.value = true
        _lastError.value = null

        viewModelScope.launch {
            try {
                val result = chatRepository.regenerateLastMessage(
                    conversationId = convId,
                    enableWebGrounding = _isWebGroundingActive.value,
                    languagePreference = settings.value.languagePreference
                )
                if (result?.error != null) {
                    _lastError.value = result.error
                }
            } catch (e: Exception) {
                _lastError.value = e.localizedMessage
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun renameConversation(id: Long, newTitle: String) {
        viewModelScope.launch {
            chatRepository.updateConversationTitle(id, newTitle)
        }
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            chatRepository.deleteConversation(id)
            if (_currentConversationId.value == id) {
                _currentConversationId.value = -1L
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            chatRepository.clearAllHistory()
            _currentConversationId.value = -1L
        }
    }

    fun speakText(text: String) {
        stopSpeaking()
        val cleanText = text.replace(Regex("```[\\s\\S]*?```"), " Code block omitted. ")
            .replace(Regex("[#*`_-]"), "")
        tts?.setSpeechRate(settings.value.ttsSpeechRate)
        tts?.setPitch(settings.value.ttsPitch)
        _currentSpeakingText.value = text
        _isPlayingTts.value = true
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "UTTERANCE_ID")
    }

    fun stopSpeaking() {
        tts?.stop()
        _isPlayingTts.value = false
        _currentSpeakingText.value = null
    }

    // Settings proxies
    fun updateDarkMode(isDark: Boolean) = settingsRepository.updateDarkMode(isDark)
    fun updateEdgeGlow(enabled: Boolean) = settingsRepository.updateEdgeGlow(enabled)
    fun updateEdgeGlowIntensity(intensity: Float) = settingsRepository.updateEdgeGlowIntensity(intensity)
    fun updateLanguage(lang: String) = settingsRepository.updateLanguage(lang)
    fun updateTtsAutoPlay(auto: Boolean) = settingsRepository.updateTtsAutoPlay(auto)
    fun updateTtsSettings(rate: Float, pitch: Float) = settingsRepository.updateTtsSettings(rate, pitch)
    fun updateProfile(name: String, email: String, photoUrl: String = "") = settingsRepository.updateProfile(name, email, photoUrl)
    fun updateUserPlan(plan: String) = settingsRepository.updateUserPlan(plan)

    // Google Authentication
    fun isUserLoggedIn(): Boolean = authRepository.isUserLoggedIn()

    fun signInWithGoogle(activity: Activity, onShowFallbackDialog: () -> Unit) {
        authRepository.signInWithGoogle(activity, onShowFallbackDialog)
    }

    fun completeSignInWithAccount(email: String, displayName: String, photoUrl: String? = null) {
        authRepository.completeSignInWithAccount(email, displayName, photoUrl)
    }

    fun signOut(activity: Activity? = null) {
        authRepository.signOut(activity)
        _currentConversationId.value = -1L
        clearAttachedMedia()
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
