package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = NexaCyan,
    onPrimary = Color.Black,
    primaryContainer = NexaDarkSurfaceElevated,
    onPrimaryContainer = NexaCyan,
    secondary = NexaPurple,
    onSecondary = Color.White,
    secondaryContainer = NexaDarkSurfaceVariant,
    onSecondaryContainer = NexaPurple,
    tertiary = NexaPink,
    onTertiary = Color.White,
    background = NexaDarkBackground,
    onBackground = Color(0xFFF0F2FD),
    surface = NexaDarkSurface,
    onSurface = Color(0xFFE6E8F6),
    surfaceVariant = NexaDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFB0B5D0),
    outline = NexaDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0284C7),
    onPrimary = Color.White,
    primaryContainer = NexaLightSurfaceElevated,
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFF7C3AED),
    onSecondary = Color.White,
    secondaryContainer = NexaLightSurfaceVariant,
    onSecondaryContainer = Color(0xFF6D28D9),
    tertiary = Color(0xFFDB2777),
    onTertiary = Color.White,
    background = NexaLightBackground,
    onBackground = NexaLightTextPrimary,
    surface = NexaLightSurface,
    onSurface = NexaLightTextPrimary,
    surfaceVariant = NexaLightSurfaceVariant,
    onSurfaceVariant = NexaLightTextSecondary,
    outline = NexaLightBorder
)

@Composable
fun NexaTheme(
    darkTheme: Boolean = false, // Clean white theme by default as requested
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backwards compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    NexaTheme(darkTheme = darkTheme, content = content)
}
