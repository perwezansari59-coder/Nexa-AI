package com.example.ui.components

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader

data class DocumentInfo(
    val name: String,
    val sizeBytes: Long,
    val contentText: String,
    val isSuccess: Boolean,
    val errorMessage: String? = null
)

object DocumentHelper {

    fun readDocument(context: Context, uri: Uri): DocumentInfo {
        var fileName = "Document"
        var fileSize = 0L

        // Retrieve file metadata
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex)
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            // fallback
        }

        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return DocumentInfo(
                    name = fileName,
                    sizeBytes = fileSize,
                    contentText = "",
                    isSuccess = false,
                    errorMessage = "Could not access the selected document."
                )

            val stringBuilder = StringBuilder()
            BufferedReader(InputStreamReader(inputStream)).use { reader ->
                var line = reader.readLine()
                var linesCount = 0
                while (line != null && linesCount < 600) {
                    stringBuilder.append(line).append("\n")
                    line = reader.readLine()
                    linesCount++
                }
            }

            val extracted = stringBuilder.toString().trim()
            if (extracted.isEmpty()) {
                DocumentInfo(
                    name = fileName,
                    sizeBytes = fileSize,
                    contentText = "Document ($fileName) uploaded. Please analyze its contents or provide summary.",
                    isSuccess = true
                )
            } else {
                DocumentInfo(
                    name = fileName,
                    sizeBytes = fileSize,
                    contentText = extracted,
                    isSuccess = true
                )
            }
        } catch (e: Exception) {
            DocumentInfo(
                name = fileName,
                sizeBytes = fileSize,
                contentText = "",
                isSuccess = false,
                errorMessage = "Failed to parse document: ${e.localizedMessage ?: "Format not supported"}"
            )
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 KB"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return if (mb >= 1.0) {
            String.format("%.1f MB", mb)
        } else {
            String.format("%.1f KB", kb)
        }
    }
}
